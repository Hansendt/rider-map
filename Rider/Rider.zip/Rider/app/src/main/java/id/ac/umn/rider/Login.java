package id.ac.umn.rider;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

public class Login extends AppCompatActivity {

    private ImageButton btnBack;
    private EditText inEmail, inPass;
    private TextView goSignup;
    private Button btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_login);

        btnBack = findViewById(R.id.btnBack);
        inEmail = findViewById(R.id.inEmail);
        inPass = findViewById(R.id.inPass);
        goSignup = findViewById(R.id.goSignup);
        btnLogin = findViewById(R.id.btnLogin);

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent backWelcome = new Intent(Login.this, Welcome_2.class);
                startActivity(backWelcome);
            }
        });

        goSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent inSignup = new Intent(Login.this, Signup.class);
                startActivity(inSignup);
            }
        });

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentHome = new Intent(Login.this, Home.class);
                startActivity(intentHome);
            }
        });
    }
}