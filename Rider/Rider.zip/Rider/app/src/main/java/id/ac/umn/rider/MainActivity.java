package id.ac.umn.rider;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button btnWelcomePage, btnLoginPage, btnSignupPage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_main);

        btnWelcomePage = findViewById(R.id.btnWelcomePage);
        btnLoginPage = findViewById(R.id.btnLoginPage);
        btnSignupPage = findViewById(R.id.btnSignupPage);

        btnWelcomePage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentWelcome = new Intent(MainActivity.this, Welcome_1.class);
                startActivity(intentWelcome);
            }
        });

        btnLoginPage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentLogin = new Intent(MainActivity.this, Login.class);
                startActivity(intentLogin);
            }
        });

        btnSignupPage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentSignup = new Intent(MainActivity.this, Signup.class);
                startActivity(intentSignup);
            }
        });
    }
}