package id.ac.umn.rider;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

public class Signup extends AppCompatActivity {

    private ImageButton btnBacktoWelcome;
    private Button btnSignupConfirm;
    private EditText signFname, signLname, signEmail, signEmailConfirm, signPass, signPassConfirm;
    private TextView goLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_signup);

        btnBacktoWelcome = findViewById(R.id.btnBacktoWelcome);
        btnSignupConfirm = findViewById(R.id.btnSignupConfirm);

        btnBacktoWelcome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent backWelcome2 = new Intent(Signup.this, Welcome_2.class);
                startActivity(backWelcome2);
            }
        });

        btnSignupConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent inSignupConfirm = new Intent(Signup.this, Login.class);
                startActivity(inSignupConfirm);
            }
        });

        goLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent inLogin = new Intent(Signup.this, Login.class);
                startActivity(inLogin);
            }
        });


    }
}